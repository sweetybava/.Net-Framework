﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project03
{
    class StoryBO
    {
        public Story CreateCustomer(string sample)
        {
            string[] s1 = sample.Split(',');
            //private string name; string authorName;string genre; int noOfChapters;int noOfLikes;int noOfReads;
            Story value = new Story(s1[0], s1[1], s1[2], Convert.ToInt32(s1[3]), Convert.ToInt32(s1[4]), Convert.ToInt32(s1[5]));
            return value;
        }
    }
}
