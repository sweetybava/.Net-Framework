﻿using System;

namespace Project03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of stories:");
            int choice = Convert.ToInt32(Console.ReadLine());

            Story[] stories = new Story[choice];
            StoryBO storyBO = new StoryBO();

            for(int i=0; i<stories.Length; i++)
            {

                string details = Console.ReadLine();

                stories[i] = storyBO.CreateCustomer(details);
            }
        }
    }
}
